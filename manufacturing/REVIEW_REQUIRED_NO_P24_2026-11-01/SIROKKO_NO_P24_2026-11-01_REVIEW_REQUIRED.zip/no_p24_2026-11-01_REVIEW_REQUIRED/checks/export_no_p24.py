#!/usr/bin/env python3
import csv
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path("/projects/exports/sirokko_max31856_modules/no_p24_project")
PCB = ROOT / "Sirokko26201_control_motor_candidate.kicad_pcb"
SCH = ROOT / "Sirokko26201_control_motor_candidate.kicad_sch"
DATE = "2026-11-01"
OUT = ROOT / "manufacturing" / f"no_p24_{DATE}_REVIEW_REQUIRED"
ZIP = ROOT / "manufacturing" / f"SIROKKO_NO_P24_{DATE}_REVIEW_REQUIRED.zip"
TARGET_REFS = {"U20", "Q20", "D20", "R120", "R121", "R122", "R123", "C28"}
EXPECTED_PARITY = {
    "Missing footprint C109 (33nF 100V C0G 5% CdVdT WIP)",
    "Missing footprint R108 (22k 1% CdVdT isolation WIP)",
}
commands = []


def run(args, expected=(0,)):
    result = subprocess.run(args, text=True, capture_output=True)
    commands.append({"command": args, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
    if result.returncode not in expected:
        raise RuntimeError(f"command failed ({result.returncode}): {' '.join(args)}\n{result.stdout}\n{result.stderr}")


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def refs_from_csv(path, column):
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return {row[column].strip() for row in csv.DictReader(stream) if row.get(column, "").strip()}


def main():
    if OUT.exists() or ZIP.exists():
        raise SystemExit(f"refusing to overwrite existing export: {OUT} or {ZIP}")
    for subdir in ("gerber", "drill", "assembly", "bom", "documentation", "checks"):
        (OUT / subdir).mkdir(parents=True, exist_ok=True)

    drc = OUT / "checks/drc.json"
    erc = OUT / "checks/erc.json"
    run(["kicad-cli", "pcb", "drc", "--all-track-errors", "--schematic-parity", "--severity-all", "--exit-code-violations", "--refill-zones", "--format", "json", "-o", str(drc), str(PCB)], expected=(5,))
    run(["kicad-cli", "sch", "erc", "--severity-all", "--exit-code-violations", "--format", "json", "-o", str(erc), str(SCH)])
    run(["kicad-cli", "pcb", "export", "gerbers", "--layers", "F.Cu,B.Cu,F.Paste,B.Paste,F.Mask,B.Mask,F.Silkscreen,B.Silkscreen,Edge.Cuts", "--exclude-value", "--precision", "6", "--check-zones", "-o", str(OUT / "gerber") + "/", str(PCB)])
    run(["kicad-cli", "pcb", "export", "drill", "--format", "excellon", "--drill-origin", "absolute", "--excellon-units", "mm", "--excellon-zeros-format", "decimal", "--excellon-oval-format", "route", "--excellon-separate-th", "--generate-map", "--map-format", "pdf", "--generate-report", "--report-path", str(OUT / "drill/DRILL_REPORT_REVIEW_REQUIRED.txt"), "-o", str(OUT / "drill") + "/", str(PCB)])
    run(["kicad-cli", "pcb", "export", "pos", "--side", "both", "--format", "csv", "--units", "mm", "--exclude-dnp", "-o", str(OUT / "assembly/POSITIONS_ALL_REVIEW_REQUIRED.csv"), str(PCB)])
    run(["kicad-cli", "pcb", "export", "pos", "--side", "both", "--format", "csv", "--units", "mm", "--smd-only", "--exclude-fp-th", "--exclude-dnp", "-o", str(OUT / "assembly/POSITIONS_SMD_REVIEW_REQUIRED.csv"), str(PCB)])
    run(["kicad-cli", "pcb", "export", "pdf", "--layers", "F.Fab,F.Silkscreen,Edge.Cuts", "--mode-single", "--scale", "0", "--exclude-value", "--sketch-pads-on-fab-layers", "--black-and-white", "--no-property-popups", "-o", str(OUT / "assembly/ASSEMBLY_FRONT_REVIEW_REQUIRED.pdf"), str(PCB)])
    run(["kicad-cli", "pcb", "export", "pdf", "--layers", "B.Fab,B.Silkscreen,Edge.Cuts", "--mirror", "--mode-single", "--scale", "0", "--exclude-value", "--sketch-pads-on-fab-layers", "--black-and-white", "--no-property-popups", "-o", str(OUT / "assembly/ASSEMBLY_BACK_MIRRORED_REVIEW_REQUIRED.pdf"), str(PCB)])
    # KiCad returns 2 after producing the STEP when optional 3D models are unavailable.
    run(["kicad-cli", "pcb", "export", "step", "--force", "--subst-models", "--no-dnp", "-o", str(OUT / "assembly/Sirokko26201_no_p24_REVIEW_REQUIRED.step"), str(PCB)], expected=(0, 2))
    run(["kicad-cli", "sch", "export", "pdf", "--black-and-white", "--exclude-pdf-property-popups", "-o", str(OUT / "documentation/Sirokko26201_no_p24_schematic_REVIEW_REQUIRED.pdf"), str(SCH)])
    bom = OUT / "bom/BOM_NO_P24_REVIEW_REQUIRED.csv"
    run(["kicad-cli", "sch", "export", "bom", "-o", str(bom), str(SCH)])

    source_checks = ROOT / "checks_no_p24"
    for name in ("removal_manifest.json", "native_connectivity_audit.json", "pcb_baseline_snapshot.json", "pcb_after_snapshot.json"):
        shutil.copy2(source_checks / name, OUT / "checks" / name)
    shutil.copy2(source_checks / "render_before/Sirokko26201_control_motor_candidate-3d-top.png", OUT / "documentation/PCB_BEFORE_TOP.png")
    shutil.copy2(source_checks / "render_after/Sirokko26201_control_motor_candidate-3d-top.png", OUT / "documentation/PCB_AFTER_NO_P24_TOP.png")

    drc_data = json.loads(drc.read_text())
    erc_data = json.loads(erc.read_text())
    audit = json.loads((OUT / "checks/native_connectivity_audit.json").read_text())
    parity = {item["description"] for item in drc_data.get("schematic_parity", [])}
    bom_refs = refs_from_csv(bom, "Refs")
    all_pos_refs = refs_from_csv(OUT / "assembly/POSITIONS_ALL_REVIEW_REQUIRED.csv", "Ref")
    smd_pos_refs = refs_from_csv(OUT / "assembly/POSITIONS_SMD_REVIEW_REQUIRED.csv", "Ref")
    gerbers = sorted((OUT / "gerber").glob("*"))
    step_path = OUT / "assembly/Sirokko26201_no_p24_REVIEW_REQUIRED.step"
    step_command = next(entry for entry in commands if entry["command"][1:4] == ["pcb", "export", "step"])
    audit_summary = {
        "date": DATE,
        "pcb_sha256": sha256(PCB),
        "schematic_sha256": sha256(SCH),
        "drc_violations": len(drc_data.get("violations", [])),
        "drc_unconnected_items": len(drc_data.get("unconnected_items", [])),
        "schematic_parity_descriptions": sorted(parity),
        "schematic_parity_expected_only": parity == EXPECTED_PARITY,
        "erc_violations": len(erc_data.get("violations", [])),
        "native_connectivity_audit_pass": audit.get("pass") is True,
        "target_refs_absent_from_bom": not (bom_refs & TARGET_REFS),
        "target_refs_absent_from_all_positions": not (all_pos_refs & TARGET_REFS),
        "target_refs_absent_from_smd_positions": not (smd_pos_refs & TARGET_REFS),
        "bom_refs": len(bom_refs),
        "all_positions": len(all_pos_refs),
        "smd_positions": len(smd_pos_refs),
        "gerber_files": len(gerbers),
        "gerber_layer_files": sum(path.suffix != ".gbrjob" for path in gerbers),
        "gerber_job_files": sum(path.suffix == ".gbrjob" for path in gerbers),
        "step_export_exit_code": step_command["exit_code"],
        "step_export_has_missing_optional_models": step_command["exit_code"] == 2,
        "step_file_bytes": step_path.stat().st_size,
        "review_required": True,
        "manufacturing_ready": False,
    }
    required_true = [
        "schematic_parity_expected_only", "native_connectivity_audit_pass",
        "target_refs_absent_from_bom", "target_refs_absent_from_all_positions",
        "target_refs_absent_from_smd_positions",
    ]
    assert audit_summary["drc_violations"] == 0
    assert audit_summary["drc_unconnected_items"] == 0
    assert audit_summary["erc_violations"] == 0
    assert all(audit_summary[key] for key in required_true)
    assert audit_summary["gerber_layer_files"] == 9
    assert audit_summary["gerber_job_files"] == 1
    assert audit_summary["step_file_bytes"] > 0
    assert {"R108", "C109"} <= bom_refs

    (OUT / "checks/CAM_NATIVE_AUDIT.json").write_text(json.dumps(audit_summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    (OUT / "checks/EXPORT_COMMANDS.json").write_text(json.dumps(commands, ensure_ascii=False, indent=2) + "\n")
    readme = f"""Sirokko 26201 — вариант без P24\n\nДата: {DATE}\nСостояние: REVIEW REQUIRED / НЕ ДЛЯ ЗАКАЗА / manufacturing_ready=false\n\nУдалено с платы: U20, Q20, D20, R120, R121, R122, R123, C28 и связанная медь P24. J1.6 оставлен NC.\nСхема уже не содержит P24; ERC: 0 нарушений.\nПлата: DRC 0 нарушений, 0 разрывов. Проверка связности до/после: пройдена.\nПроверка соответствия схеме: остаются только заранее известные отсутствующие посадочные места R108 и C109 (CdVdT WIP).\n\nSTEP создан, но KiCad сообщил об отсутствующих необязательных 3D-моделях TP101, U11, U13, D1 и L101; см. checks/EXPORT_COMMANDS.json.

Пакет предназначен для инженерной проверки. Заказывать платы по нему нельзя до отдельного подтверждения R108/C109, механики, состава, неполных 3D-моделей и снятия статуса REVIEW REQUIRED.\n"""
    (OUT / "README_RU.md").write_text(readme)

    checksum_lines = []
    for path in sorted(p for p in OUT.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt"):
        checksum_lines.append(f"{sha256(path)}  {path.relative_to(OUT)}")
    (OUT / "SHA256SUMS.txt").write_text("\n".join(checksum_lines) + "\n")

    with zipfile.ZipFile(ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(p for p in OUT.rglob("*") if p.is_file()):
            archive.write(path, Path(OUT.name) / path.relative_to(OUT))
    print(json.dumps({"output": str(OUT), "zip": str(ZIP), "zip_sha256": sha256(ZIP), "audit": audit_summary}, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
