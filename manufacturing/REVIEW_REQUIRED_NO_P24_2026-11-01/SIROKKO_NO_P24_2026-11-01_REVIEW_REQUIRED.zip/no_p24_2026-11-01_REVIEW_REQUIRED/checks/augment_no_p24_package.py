#!/usr/bin/env python3
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path("/projects/exports/sirokko_max31856_modules/no_p24_project")
OUT = ROOT / "manufacturing/no_p24_2026-11-01_REVIEW_REQUIRED"
ZIP = ROOT / "manufacturing/SIROKKO_NO_P24_2026-11-01_REVIEW_REQUIRED.zip"
SOURCE = OUT / "source"
FILES = [
    "Sirokko26201_control_motor_candidate.kicad_pro",
    "Sirokko26201_control_motor_candidate.kicad_pcb",
    "Sirokko26201_control_motor_candidate.kicad_sch",
    "MinimalSafety.kicad_sch",
    "Sirokko_Input_Protection_WIP.kicad_sch",
    "logic_power_24_5_DRAFT.kicad_sch",
    "motor_external_hc160.kicad_sch",
    "fp-lib-table",
    "sym-lib-table",
    "Sirokko_Input_Protection.kicad_sym",
    "Sirokko_Interface.kicad_sym",
    "Sirokko_Power.kicad_sym",
    "Sirokko_Relay_Driver.kicad_sym",
    "3dmodels/DG85BM_DZ85AB_installed_envelope.wrl",
    "3dmodels/Keystone3568_Littelfuse0997030_envelope.wrl",
    "3dmodels/Phoenix_1756993_envelope.wrl",
]
DIRS = [
    "Sirokko_Capacitor.pretty",
    "Sirokko_Input.pretty",
    "Sirokko_Mechanical.pretty",
    "Sirokko_Module.pretty",
    "Sirokko_Power.pretty",
    "Sirokko_Relay_Mechanical.pretty",
]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


if SOURCE.exists():
    raise SystemExit(f"refusing to overwrite {SOURCE}")
SOURCE.mkdir()
for name in FILES:
    src = ROOT / name
    assert src.is_file(), src
    dest = SOURCE / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
for name in DIRS:
    src = ROOT / name
    assert src.is_dir(), src
    shutil.copytree(src, SOURCE / name)

source_files = sorted(path for path in SOURCE.rglob("*") if path.is_file())
source_manifest = {
    "date": "2026-11-01",
    "source_root": str(ROOT),
    "files": {str(path.relative_to(SOURCE)): sha256(path) for path in source_files},
    "missing_optional_standard_3d_models": ["TP101", "U11", "U13", "D1", "L101"],
}
(SOURCE / "SOURCE_SHA256.json").write_text(json.dumps(source_manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n")

audit_path = OUT / "checks/CAM_NATIVE_AUDIT.json"
audit = json.loads(audit_path.read_text())
audit["source_files"] = len(source_files) + 1
audit["source_project_included"] = True
audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2, sort_keys=True) + "\n")

readme = OUT / "README_RU.md"
text = readme.read_text()
text += "\nИсходники KiCad, точные для этого проверенного снимка, находятся в каталоге source/.\n"
readme.write_text(text)

checksums = OUT / "SHA256SUMS.txt"
checksum_lines = []
for path in sorted(path for path in OUT.rglob("*") if path.is_file() and path != checksums):
    checksum_lines.append(f"{sha256(path)}  {path.relative_to(OUT)}")
checksums.write_text("\n".join(checksum_lines) + "\n")

tmp_zip = ZIP.with_suffix(".zip.new")
with zipfile.ZipFile(tmp_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(path for path in OUT.rglob("*") if path.is_file()):
        archive.write(path, Path(OUT.name) / path.relative_to(OUT))
with zipfile.ZipFile(tmp_zip) as archive:
    assert archive.testzip() is None
    entries = len(archive.infolist())
tmp_zip.replace(ZIP)
print(json.dumps({"source_files": len(source_files) + 1, "zip_entries": entries, "zip_sha256": sha256(ZIP)}, sort_keys=True))
