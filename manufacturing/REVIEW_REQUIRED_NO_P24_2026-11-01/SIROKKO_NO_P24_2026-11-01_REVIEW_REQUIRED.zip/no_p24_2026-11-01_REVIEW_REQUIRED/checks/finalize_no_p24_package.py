#!/usr/bin/env python3
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path("/projects/exports/sirokko_max31856_modules/no_p24_project")
OUT = ROOT / "manufacturing/no_p24_2026-11-01_REVIEW_REQUIRED"
ZIP = ROOT / "manufacturing/SIROKKO_NO_P24_2026-11-01_REVIEW_REQUIRED.zip"
CHECKS = ROOT / "checks_no_p24"


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


names = ["audit_no_p24.py", "export_no_p24.py", "augment_no_p24_package.py", "finalize_no_p24_package.py"]
for name in names:
    src = CHECKS / name
    assert src.is_file(), src
    shutil.copy2(src, OUT / "checks" / name)

audit_path = OUT / "checks/CAM_NATIVE_AUDIT.json"
audit = json.loads(audit_path.read_text())
audit["audit_scripts_included"] = names
audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2, sort_keys=True) + "\n")

readme = OUT / "README_RU.md"
text = readme.read_text()
text += "Сценарии воспроизведения снимков, экспорта и упаковки находятся в checks/*.py.\n"
readme.write_text(text)

checksums = OUT / "SHA256SUMS.txt"
lines = []
for path in sorted(path for path in OUT.rglob("*") if path.is_file() and path != checksums):
    lines.append(f"{sha256(path)}  {path.relative_to(OUT)}")
checksums.write_text("\n".join(lines) + "\n")

tmp = ZIP.with_suffix(".zip.new")
with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(path for path in OUT.rglob("*") if path.is_file()):
        archive.write(path, Path(OUT.name) / path.relative_to(OUT))
with zipfile.ZipFile(tmp) as archive:
    assert archive.testzip() is None
    entries = len(archive.infolist())
tmp.replace(ZIP)
print(json.dumps({"zip_entries": entries, "zip_sha256": sha256(ZIP)}, sort_keys=True))
