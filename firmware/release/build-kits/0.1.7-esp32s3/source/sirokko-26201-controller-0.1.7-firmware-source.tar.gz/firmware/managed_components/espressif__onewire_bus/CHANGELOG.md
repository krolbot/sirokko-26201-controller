## 1.1.2

- Fix 1-Wire ROM search using AN187 1-based bit numbering so `LastDiscrepancy == 0` is a sentinel, not ROM bit 0. (https://github.com/espressif/idf-extra-components/issues/298)
- Extend the RMT reset high window (`tRSTH`) to 480us to match the 1-Wire specification.
- Document `ESP_ERR_TIMEOUT`, `ESP_ERR_INVALID_STATE`, and `ESP_ERR_INVALID_CRC` in the public API return values.
- Reject invalid RMT GPIO numbers and out-of-range `max_rx_bytes` at bus creation.

## 1.1.1

- When reading more bytes than fit in one RMT memory block on ESP32 and ESP32-S2, data will be read in chunks.

## 1.1.0

- Add UART backend support for 1-Wire bus (`onewire_new_bus_uart`) alongside the existing RMT backend.

## 1.0.4

- Support `en_pull_up` config option in `onewire_bus_config_t`, which can enable the internal pull-up resistor on the GPIO pin used for the one-wire bus. This is useful when using a GPIO pin that does not have a pull-up resistor connected externally.

## 1.0.3

- Improve the driver to support esp-idf v6.0

## 1.0.2

- raise recovery time to support more sensor on longer wire (d0b2b52)

## 1.0.0

- Initial driver version, with the RMT driver as backend controller
